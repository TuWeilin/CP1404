'''Add password check program'''


def get_password():
    password = str(input("Enter your password: "))


def main():
    password = get_password()



main()
